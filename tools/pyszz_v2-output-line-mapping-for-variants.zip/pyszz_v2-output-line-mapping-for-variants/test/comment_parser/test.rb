
 # This method prints the sum of its arguments

 def sum(a,b)

=begin

 Between =begin and =end, any number

 of lines may be written. All of these
 # This method prints the sum of its arguments

 lines are ignored by the Ruby interpreter.

=end
 # This method prints the sum of its arguments

   puts a+b

 end