# Modified cregit for MV-SZZ Study

## 1. Overview

This directory contains a modified version of the `cregit` tool, specifically adapted for use in the research project "MV-SZZ: A Majority Voting-Based SZZ Method".

The original `cregit` tool can be found at: [https://github.com/cregit/cregit]

## 2. Modifications

The primary modifications were made to the following script:

- **`tokenBySha.pl`**:
  - The tokenization window size can now be controlled externally via the new environment variable `BFG_WINDOW_SIZE`.
  - Adjusted the handling of comments and made the number of tokens per line configurable during tokenization.

## 3. Usage in This Study

Key environment variables required/used by the modified script include:

- `BFG_MEMO_DIR`: Specifies the directory for memoization of tokenized files.
- `BFG_TOKENIZE_CMD`: Defines the command to execute the tokenization script.
- `BFG_WINDOW_SIZE`: (New variable) Defines the number of tokens in the sliding window for context.
- `BFG_FILENAME`: The filename being processed (set by BFG).
- `BFG_BLOB`: The blob ID being processed (set by BFG).

## 4. License

The modified `cregit` components in this directory are licensed under the **GNU General Public License Version 3 (GPLv3) or any later version**. The full text of the GPLv3 can be found in the `LICENSE` file in the root directory of this replication package.

For information on the original `cregit` license, please refer to the `LICENSE.md` file and `original_cregit_readme.org` file in this directory.

## 5. Original Documentation

The file `original_cregit_readme.org` in this directory contains the original documentation for the `cregit` tool. It is provided for reference regarding the original tool's features and design. However, for the setup, usage, and modifications specific to this research project, please refer to this `README.md` file and the main documentation of the replication package.
